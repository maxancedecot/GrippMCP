<?php
/**
 * Plugin Name: Gripp Site Analytics
 * Description: Collecte les performances d'un site WordPress et les envoie vers le dashboard central.
 * Version: 0.2.0
 * Author: Gripp MCP
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Gripp_Site_Analytics_Plugin {
    private const VERSION = '0.2.0';
    private const OPTION_NAME = 'gripp_site_analytics_options';
    private const REST_NAMESPACE = 'gripp-site-analytics/v1';
    private const REST_ROUTE = '/event';
    private const COLLECT_PATH = '/api/site-analytics/collect';
    private const REGISTER_PATH = '/api/site-analytics/register';
    private const DEFAULT_DASHBOARD_URL = '';
    private const REGISTRATION_TOKEN = '';
    private const SCRIPT_HANDLE = 'gripp-site-analytics';

    public static function activate(): void {
        $options = get_option(self::OPTION_NAME, []);
        if (!is_array($options)) {
            $options = [];
        }

        if (empty($options['public_key'])) {
            $options['public_key'] = wp_generate_password(32, false, false);
        }

        $options = self::apply_default_dashboard_options($options);
        update_option(self::OPTION_NAME, $options, false);
    }

    public function boot(): void {
        add_action('admin_menu', [$this, 'register_admin_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'maybe_auto_register_site'], 20);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_tracker']);
    }

    public function register_admin_page(): void {
        add_options_page(
            'Gripp Site Analytics',
            'Gripp Analytics',
            'manage_options',
            'gripp-site-analytics',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings(): void {
        register_setting('gripp_site_analytics', self::OPTION_NAME, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_options'],
            'default' => []
        ]);

        add_settings_section(
            'gripp_site_analytics_main',
            'Connexion dashboard',
            '__return_false',
            'gripp-site-analytics'
        );

        add_settings_field('dashboard_url', 'URL dashboard', [$this, 'render_text_field'], 'gripp-site-analytics', 'gripp_site_analytics_main', [
            'name' => 'dashboard_url',
            'placeholder' => 'https://votre-domaine.vercel.app',
            'type' => 'url'
        ]);
        add_settings_field('track_logged_in', 'Utilisateurs connectes', [$this, 'render_checkbox_field'], 'gripp-site-analytics', 'gripp_site_analytics_main', [
            'name' => 'track_logged_in',
            'label' => 'Inclure les utilisateurs connectes'
        ]);
    }

    public function sanitize_options($input): array {
        $existing = $this->options();
        $input = is_array($input) ? $input : [];
        $existing_dashboard_url = self::dashboard_url_from_options($existing);
        $has_dashboard_input = array_key_exists('dashboard_url', $input);
        $dashboard_url = self::normalize_dashboard_url((string) ($input['dashboard_url'] ?? $existing_dashboard_url));
        $dashboard_cleared = $has_dashboard_input && $dashboard_url === '';
        $dashboard_changed = $dashboard_url !== '' && $existing_dashboard_url !== '' && $dashboard_url !== $existing_dashboard_url;
        $reset_connection = $dashboard_changed || $dashboard_cleared;
        $site_id = $reset_connection ? '' : sanitize_key($existing['site_id'] ?? '');
        $site_token = $reset_connection ? '' : sanitize_text_field($existing['site_token'] ?? '');

        return [
            'dashboard_url' => $dashboard_url,
            'endpoint_url' => $dashboard_url ? self::build_dashboard_endpoint_url($dashboard_url, self::COLLECT_PATH) : '',
            'site_id' => $site_id,
            'site_token' => $site_token,
            'track_logged_in' => !empty($input['track_logged_in']) ? '1' : '',
            'public_key' => sanitize_text_field($existing['public_key'] ?? wp_generate_password(32, false, false)),
            'registration_attempted_at' => $reset_connection ? 0 : absint($existing['registration_attempted_at'] ?? 0),
            'registration_error' => $reset_connection ? '' : sanitize_text_field($existing['registration_error'] ?? '')
        ];
    }

    public function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>Gripp Site Analytics</h1>
            <?php $this->render_connection_notice($this->options()); ?>
            <form action="options.php" method="post">
                <?php
                settings_fields('gripp_site_analytics');
                do_settings_sections('gripp-site-analytics');
                submit_button('Enregistrer');
                ?>
            </form>
        </div>
        <?php
    }

    public function render_text_field(array $args): void {
        $options = $this->options();
        $name = (string) ($args['name'] ?? '');
        $type = (string) ($args['type'] ?? 'text');
        $placeholder = (string) ($args['placeholder'] ?? '');
        $value = (string) ($options[$name] ?? '');
        if ($name === 'dashboard_url' && $value === '') {
            $value = self::DEFAULT_DASHBOARD_URL;
        }
        ?>
        <input
            class="regular-text"
            type="<?php echo esc_attr($type); ?>"
            name="<?php echo esc_attr(self::OPTION_NAME . '[' . $name . ']'); ?>"
            value="<?php echo esc_attr($value); ?>"
            placeholder="<?php echo esc_attr($placeholder); ?>"
            autocomplete="off"
        />
        <?php
    }

    public function render_checkbox_field(array $args): void {
        $options = $this->options();
        $name = (string) ($args['name'] ?? '');
        $label = (string) ($args['label'] ?? '');
        ?>
        <label>
            <input
                type="checkbox"
                name="<?php echo esc_attr(self::OPTION_NAME . '[' . $name . ']'); ?>"
                value="1"
                <?php checked(!empty($options[$name])); ?>
            />
            <?php echo esc_html($label); ?>
        </label>
        <?php
    }

    public function render_connection_notice(array $options): void {
        if ($this->is_configured($options)) {
            ?>
            <div class="notice notice-success inline">
                <p>
                    <?php echo esc_html('Connecte au dashboard. Site ID: ' . (string) $options['site_id']); ?>
                </p>
            </div>
            <?php
            return;
        }

        if (!self::dashboard_url_from_options($options)) {
            ?>
            <div class="notice notice-warning inline">
                <p>Ajoutez l'URL du dashboard pour lancer la connexion automatique.</p>
            </div>
            <?php
            return;
        }

        if (!empty($options['registration_error'])) {
            ?>
            <div class="notice notice-error inline">
                <p>
                    <?php echo esc_html('Connexion automatique echouee: ' . (string) $options['registration_error']); ?>
                </p>
            </div>
            <?php
            return;
        }

        ?>
        <div class="notice notice-info inline">
            <p>Connexion automatique en cours. Rechargez cette page si le statut ne change pas.</p>
        </div>
        <?php
    }

    public function maybe_auto_register_site(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $options = $this->options();
        if (empty($options['public_key'])) {
            $options['public_key'] = wp_generate_password(32, false, false);
            update_option(self::OPTION_NAME, $options, false);
        }

        $options_with_defaults = self::apply_default_dashboard_options($options);
        if ($options_with_defaults !== $options) {
            $options = $options_with_defaults;
            update_option(self::OPTION_NAME, $options, false);
        }

        if ($this->is_configured($options)) {
            return;
        }

        $dashboard_url = self::dashboard_url_from_options($options);
        if (!$dashboard_url) {
            return;
        }

        $last_attempt = absint($options['registration_attempted_at'] ?? 0);
        if (!empty($options['registration_error']) && $last_attempt > 0 && time() - $last_attempt < 300) {
            return;
        }

        $this->register_site_with_dashboard($options, $dashboard_url);
    }

    private function register_site_with_dashboard(array $options, string $dashboard_url): void {
        $options['registration_attempted_at'] = time();
        $options['registration_error'] = '';
        update_option(self::OPTION_NAME, $options, false);

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ];
        if (self::REGISTRATION_TOKEN !== '') {
            $headers['X-Site-Analytics-Registration-Token'] = self::REGISTRATION_TOKEN;
        }

        $response = wp_remote_post(self::build_dashboard_endpoint_url($dashboard_url, self::REGISTER_PATH), [
            'timeout' => 10,
            'redirection' => 0,
            'headers' => $headers,
            'body' => wp_json_encode([
                'site_url' => home_url('/'),
                'site_name' => get_bloginfo('name'),
                'installation_id' => (string) ($options['public_key'] ?? ''),
                'plugin_version' => self::VERSION
            ])
        ]);

        if (is_wp_error($response)) {
            $this->store_registration_error($options, $response->get_error_message());
            return;
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($body)) {
            $this->store_registration_error($options, 'le dashboard a refuse l enregistrement');
            return;
        }

        $site_id = sanitize_key($body['site_id'] ?? '');
        $site_token = sanitize_text_field($body['site_token'] ?? '');
        $collect_url = esc_url_raw($body['collect_url'] ?? self::build_dashboard_endpoint_url($dashboard_url, self::COLLECT_PATH));
        if (!$site_id || !$site_token || !$collect_url) {
            $this->store_registration_error($options, 'reponse dashboard incomplete');
            return;
        }

        $options['dashboard_url'] = $dashboard_url;
        $options['endpoint_url'] = $collect_url;
        $options['site_id'] = $site_id;
        $options['site_token'] = $site_token;
        $options['registration_error'] = '';
        update_option(self::OPTION_NAME, $options, false);
    }

    private function store_registration_error(array $options, string $message): void {
        $options['registration_error'] = sanitize_text_field($message);
        update_option(self::OPTION_NAME, $options, false);
    }

    public function register_rest_routes(): void {
        register_rest_route(self::REST_NAMESPACE, self::REST_ROUTE, [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'handle_event'],
            'permission_callback' => '__return_true'
        ]);
    }

    public function enqueue_tracker(): void {
        $options = $this->options();
        if (is_admin() || is_feed() || is_robots()) {
            return;
        }
        if (is_user_logged_in() && empty($options['track_logged_in'])) {
            return;
        }
        if (!$this->is_configured($options)) {
            return;
        }

        wp_enqueue_script(
            self::SCRIPT_HANDLE,
            plugin_dir_url(__FILE__) . 'assets/tracker.js',
            [],
            self::VERSION,
            true
        );
        wp_localize_script(self::SCRIPT_HANDLE, 'grippSiteAnalytics', [
            'restUrl' => esc_url_raw(rest_url(self::REST_NAMESPACE . self::REST_ROUTE)),
            'publicKey' => (string) $options['public_key']
        ]);
    }

    public function handle_event(WP_REST_Request $request) {
        $options = $this->options();
        if (!$this->is_configured($options)) {
            return new WP_Error('gripp_site_analytics_not_configured', 'Plugin analytics non configure.', ['status' => 503]);
        }

        $payload = $request->get_json_params();
        if (!is_array($payload) || !hash_equals((string) $options['public_key'], (string) ($payload['public_key'] ?? ''))) {
            return new WP_Error('gripp_site_analytics_forbidden', 'Evenement refuse.', ['status' => 403]);
        }

        $event = $this->sanitize_event($payload, $options);
        if (!$event) {
            return new WP_Error('gripp_site_analytics_invalid_event', 'Evenement invalide.', ['status' => 400]);
        }

        $response = wp_remote_post((string) $options['endpoint_url'], [
            'timeout' => 6,
            'redirection' => 0,
            'headers' => [
                'Authorization' => 'Bearer ' . (string) $options['site_token'],
                'Content-Type' => 'application/json'
            ],
            'body' => wp_json_encode($event)
        ]);

        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) >= 400) {
            return new WP_Error('gripp_site_analytics_forward_failed', 'Transmission analytics echouee.', ['status' => 502]);
        }

        return new WP_REST_Response(['ok' => true], 202);
    }

    private function sanitize_event(array $payload, array $options): ?array {
        $event_type = sanitize_key($payload['event_type'] ?? '');
        if (!in_array($event_type, ['page_view', 'engagement', 'scroll'], true)) {
            return null;
        }

        $visitor_id = sanitize_text_field($payload['visitor_id'] ?? '');
        $session_id = sanitize_text_field($payload['session_id'] ?? '');
        $page_view_id = sanitize_text_field($payload['page_view_id'] ?? '');
        if (!$visitor_id || !$session_id || !$page_view_id) {
            return null;
        }

        return [
            'site_id' => (string) $options['site_id'],
            'site_url' => home_url('/'),
            'event_type' => $event_type,
            'visitor_id' => $visitor_id,
            'session_id' => $session_id,
            'page_view_id' => $page_view_id,
            'page_url' => esc_url_raw($payload['page_url'] ?? ''),
            'path' => sanitize_text_field($payload['path'] ?? ''),
            'page_title' => sanitize_text_field($payload['page_title'] ?? ''),
            'referrer' => esc_url_raw($payload['referrer'] ?? ''),
            'source' => sanitize_text_field($payload['source'] ?? ''),
            'medium' => sanitize_text_field($payload['medium'] ?? ''),
            'campaign' => sanitize_text_field($payload['campaign'] ?? ''),
            'active_time_ms_delta' => min(3600000, absint($payload['active_time_ms_delta'] ?? 0)),
            'scroll_percent' => min(100, max(0, (float) ($payload['scroll_percent'] ?? 0))),
            'viewport_width' => absint($payload['viewport_width'] ?? 0),
            'viewport_height' => absint($payload['viewport_height'] ?? 0)
        ];
    }

    private function is_configured(array $options): bool {
        return !empty($options['endpoint_url']) && !empty($options['site_id']) && !empty($options['site_token']) && !empty($options['public_key']);
    }

    private static function apply_default_dashboard_options(array $options): array {
        $dashboard_url = self::dashboard_url_from_options($options);
        if (!$dashboard_url && self::DEFAULT_DASHBOARD_URL !== '') {
            $dashboard_url = self::normalize_dashboard_url(self::DEFAULT_DASHBOARD_URL);
            if ($dashboard_url) {
                $options['dashboard_url'] = $dashboard_url;
            }
        }

        if ($dashboard_url) {
            $options['dashboard_url'] = $dashboard_url;
            if (empty($options['endpoint_url'])) {
                $options['endpoint_url'] = self::build_dashboard_endpoint_url($dashboard_url, self::COLLECT_PATH);
            }
        }

        return $options;
    }

    private static function dashboard_url_from_options(array $options): string {
        $dashboard_url = self::normalize_dashboard_url((string) ($options['dashboard_url'] ?? ''));
        if ($dashboard_url) {
            return $dashboard_url;
        }

        return self::dashboard_url_from_endpoint((string) ($options['endpoint_url'] ?? ''));
    }

    private static function dashboard_url_from_endpoint(string $endpoint_url): string {
        $endpoint_url = esc_url_raw($endpoint_url);
        if (!$endpoint_url) {
            return '';
        }

        $parts = parse_url($endpoint_url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $path = (string) ($parts['path'] ?? '');
        if (substr($path, -strlen(self::COLLECT_PATH)) !== self::COLLECT_PATH) {
            return self::normalize_dashboard_url($endpoint_url);
        }

        $base_path = substr($path, 0, -strlen(self::COLLECT_PATH));
        $origin = strtolower((string) $parts['scheme']) . '://' . (string) $parts['host'];
        if (!empty($parts['port'])) {
            $origin .= ':' . (string) $parts['port'];
        }

        return self::normalize_dashboard_url($origin . $base_path);
    }

    private static function normalize_dashboard_url(string $dashboard_url): string {
        $dashboard_url = esc_url_raw(trim($dashboard_url));
        if (!$dashboard_url) {
            return '';
        }

        $parts = parse_url($dashboard_url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $scheme = strtolower((string) $parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return '';
        }

        $url = $scheme . '://' . (string) $parts['host'];
        if (!empty($parts['port'])) {
            $url .= ':' . (string) $parts['port'];
        }
        if (!empty($parts['path']) && $parts['path'] !== '/') {
            $url .= '/' . trim((string) $parts['path'], '/');
        }

        return rtrim($url, '/');
    }

    private static function build_dashboard_endpoint_url(string $dashboard_url, string $path): string {
        return rtrim($dashboard_url, '/') . $path;
    }

    private function options(): array {
        $options = get_option(self::OPTION_NAME, []);
        return is_array($options) ? $options : [];
    }
}

register_activation_hook(__FILE__, ['Gripp_Site_Analytics_Plugin', 'activate']);
(new Gripp_Site_Analytics_Plugin())->boot();
